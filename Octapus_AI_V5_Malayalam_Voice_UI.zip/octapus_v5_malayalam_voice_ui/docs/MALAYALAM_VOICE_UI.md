# Octapus AI — Malayalam Voice UI

This package is a replacement for `frontend/index.html`.

## What it adds

- Malayalam-first interface (`ml-IN`)
- Malayalam speech-to-text using the browser Web Speech API
- Malayalam text-to-speech using the browser Speech Synthesis API
- Voice conversation panel with animated listening orb
- Normal / Fun / Quiz / Study / Travel / Explore / Local / Research / Story modes
- Direct calls to the V5 endpoint: `POST /api/v5/engine`
- V5 health/capability checks
- Local conversation history and V5 state
- Minimal responsive UI for desktop and mobile
- Place cards when the V5 response contains place results

## Install

Copy:

`frontend/index.html`

into your project, replacing the existing `frontend/index.html`.

Your existing `v4/gpt.py` already exposes:

- `/api/v5/engine`
- `/api/v5/modes`
- `/api/v5/voice/capabilities`

Start the backend normally, then open the root page.

## Malayalam note

The UI and browser voice layer are Malayalam-first. The current V5 engine still contains several English deterministic response templates and English source snippets. For fully Malayalam answers from the engine itself, the next backend step should localize the V5 response builder/parser while keeping the deterministic/no-LLM architecture.
