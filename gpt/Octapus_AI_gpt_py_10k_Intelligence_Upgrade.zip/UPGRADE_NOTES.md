# Octapus AI GPT Backend Upgrade

## What changed

This is an upgraded `gpt.py` based on the uploaded 5,164-line backend.

The file is intentionally larger than 10,000 lines, but the added code is not
random padding. The upgrade adds a deterministic intelligence/retrieval layer
designed to improve the quality of the browser-side Puter AI agent.

### Main upgrades

- Query normalization and query expansion
- Malayalam / English / mixed-language detection
- Budget extraction
- Party-size extraction
- Trip-duration extraction
- Travel preference extraction
- District and destination hints
- Multi-intent confidence scoring
- Deterministic query planning
- Better place ranking with multiple signals
- Constraint-aware ranking
- Diversity-aware recommendation lists
- Better follow-up/reference resolution
- Conversation-state reconstruction
- Evidence/source metadata
- Current-information verification policy
- Trip itinerary planning helpers
- Budget allocation helpers
- Place comparison helpers
- Better local-service tool handling
- Better live-search result envelopes
- Better travel endpoint handling
- Better tool error envelopes
- Expanded Kerala destination lexicon
- Intelligence health endpoint
- Intelligence planning endpoint
- Conversation-resolution endpoint
- Intelligence debug endpoint
- Deterministic regression probes
- Public intelligence version endpoint
- Improved Puter system prompt
- Improved Puter tool descriptions
- Improved initial Puter context

## Important architecture

Puter remains the browser-side AI layer. The backend does not add a second
LLM call to normal Puter conversations.

The backend's job is to provide stronger retrieval, grounding, constraints,
context and tool results.

## Existing compatibility

The original V4/V5 endpoints and Firebase/Firestore architecture are retained.
The upgraded agent tool functions keep the existing tool names so the current
frontend can continue using:

- search_places
- get_place
- search_services
- live_search
- travel_info
- search_knowledge

## Validation

- Python syntax compilation passed.
- Original backend was preserved as the basis for the upgrade.
- No Firebase credentials or API keys are included in this package.
